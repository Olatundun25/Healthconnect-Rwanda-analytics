-- =====================================================================
-- HealthConnect Rwanda | Step 1: Create all empty tables
-- Run this whole file ONCE in pgAdmin Query Tool (database: healthconnect)
-- Column order matches each CSV file exactly, so imports line up.
-- =====================================================================

-- ---------- LOCATION TABLES ----------
CREATE TABLE countries (
    country_id   VARCHAR(10) PRIMARY KEY,
    country_name TEXT, iso2 TEXT, iso3 TEXT, currency TEXT, region TEXT
);
CREATE TABLE provinces (
    province_id   VARCHAR(10) PRIMARY KEY,
    province_name TEXT,
    country_id    VARCHAR(10)
);
CREATE TABLE districts (
    district_id   VARCHAR(10) PRIMARY KEY,
    district_name TEXT,
    province_id   VARCHAR(10)
);
CREATE TABLE sectors (
    sector_id   VARCHAR(10) PRIMARY KEY,
    sector_name TEXT,
    district_id VARCHAR(10)
);
CREATE TABLE villages (
    village_id   VARCHAR(10) PRIMARY KEY,
    village_name TEXT,
    sector_id    VARCHAR(10)
);
CREATE TABLE ownership_types (
    ownership_id VARCHAR(10) PRIMARY KEY,
    ownership    TEXT
);

-- ---------- FACILITY STRUCTURE ----------
CREATE TABLE departments (
    department_id   VARCHAR(10) PRIMARY KEY,
    department_name TEXT,
    facility_id     VARCHAR(10)
);
CREATE TABLE medical_specialties (
    specialty_id  VARCHAR(10) PRIMARY KEY,
    specialty     TEXT,
    department_id VARCHAR(10)
);
CREATE TABLE services (
    service_id    VARCHAR(10) PRIMARY KEY,
    service_name  TEXT,
    department_id VARCHAR(10)
);
CREATE TABLE medical_equipment (
    equipment_id   VARCHAR(10) PRIMARY KEY,
    equipment_name TEXT,
    department_id  VARCHAR(10),
    facility_id    VARCHAR(10)
);
CREATE TABLE rooms (
    room_id       VARCHAR(10) PRIMARY KEY,
    department_id VARCHAR(10),
    facility_id   VARCHAR(10),
    room_name     TEXT
);
CREATE TABLE beds (
    bed_id  VARCHAR(12) PRIMARY KEY,
    room_id VARCHAR(10),
    status  TEXT
);

-- ---------- STAFF (6 files, same columns) ----------
CREATE TABLE doctors (
    staff_id VARCHAR(10) PRIMARY KEY, first_name TEXT, last_name TEXT, role TEXT,
    department TEXT, specialty TEXT, facility_id VARCHAR(10), department_id VARCHAR(10),
    years_experience INT, status TEXT
);
CREATE TABLE nurses (LIKE doctors INCLUDING ALL);
CREATE TABLE pharmacists (LIKE doctors INCLUDING ALL);
CREATE TABLE laboratory_scientists (LIKE doctors INCLUDING ALL);
CREATE TABLE radiographers (LIKE doctors INCLUDING ALL);
CREATE TABLE administrative_staff (LIKE doctors INCLUDING ALL);

-- ---------- PATIENTS ----------
-- date_of_birth and phone are TEXT on purpose: the CSV uses M/D/YYYY dates
-- and the phone numbers were damaged by Excel (2.50788E+11). We handle both
-- in the cleaning step.
CREATE TABLE patients (
    patient_id        VARCHAR(12) PRIMARY KEY,
    first_name        TEXT,
    last_name         TEXT,
    gender            TEXT,
    date_of_birth     TEXT,
    age               INT,
    marital_status    TEXT,
    occupation        TEXT,
    education         TEXT,
    village_id        VARCHAR(10),
    insurance_id      VARCHAR(10),
    blood_group       TEXT,
    height_cm         NUMERIC,
    weight_kg         NUMERIC,
    chronic_condition TEXT,
    phone             TEXT,
    emergency_contact TEXT,
    status            TEXT,
    bmi               NUMERIC
);

-- ---------- CLINICAL TRANSACTIONS ----------
CREATE TABLE clinical_transactions (      -- this is your APPOINTMENTS table
    appointment_id VARCHAR(12) PRIMARY KEY,
    patient_id     VARCHAR(12),
    doctor_id      VARCHAR(10),
    facility_id    VARCHAR(10),
    department_id  VARCHAR(10),
    appointment_date TEXT,                -- M/D/YYYY text, converted later
    visit_type     TEXT
);
CREATE TABLE diagnoses (
    diagnosis_id   VARCHAR(12) PRIMARY KEY,
    appointment_id VARCHAR(12),
    diagnosis      TEXT,
    severity       TEXT
);

-- ---------- FINANCE ----------
CREATE TABLE billing (
    billing_id     VARCHAR(12) PRIMARY KEY,
    appointment_id VARCHAR(12),
    amount         NUMERIC,
    status         TEXT
);
CREATE TABLE insurance_claims (
    claim_id     VARCHAR(12) PRIMARY KEY,
    billing_id   VARCHAR(12),
    provider     TEXT,
    claim_amount NUMERIC,
    status       TEXT
);
CREATE TABLE payments (
    payment_id   VARCHAR(12) PRIMARY KEY,
    billing_id   VARCHAR(12),
    amount_paid  NUMERIC,
    method       TEXT
);
CREATE TABLE patient_feedback (
    feedback_id    VARCHAR(12) PRIMARY KEY,
    appointment_id VARCHAR(12),
    rating         INT,
    comment        TEXT
);
CREATE TABLE revenue_summary (
    month        TEXT,
    revenue      NUMERIC,
    appointments INT
);

-- Check: this should list 26 tables
SELECT count(*) AS tables_created
FROM information_schema.tables WHERE table_schema = 'public';
