-- Q1: Retrieve all registered patients
SELECT patient_id, first_name, last_name, gender, age, province_name, district_name, insurance_id
FROM v_patients
ORDER BY patient_id;

-- Q2: Count patients by gender
SELECT gender, count(*) AS total_patients
FROM v_patients
GROUP BY gender
ORDER BY total_patients DESC;

-- Q3: Count patients by province
SELECT province_name, count(*) AS total_patients
FROM v_patients
GROUP BY province_name
ORDER BY total_patients DESC;

-- Q4: Identify patients above 65 years
SELECT patient_id, first_name, last_name, gender, age
FROM v_patients
WHERE age > 65
ORDER BY age DESC;

-- Q5: Find patients with chronic diseases
SELECT chronic_condition, count(*) AS total_patients
FROM v_patients
WHERE chronic_condition <> 'None'
GROUP BY chronic_condition
ORDER BY total_patients DESC;

-- Q6: Retrieve patients covered by insurance
SELECT patient_id, first_name, last_name, insurance_id
FROM v_patients
WHERE insurance_id IS NOT NULL AND insurance_id <> ''
ORDER BY patient_id;

-- Q7: Count patients by blood group
SELECT blood_group, count(*) AS total_patients
FROM v_patients
GROUP BY blood_group
ORDER BY total_patients DESC;

-- Q8: List the youngest and oldest patients
(SELECT 'Youngest' AS category, patient_id, first_name, last_name, age
 FROM v_patients ORDER BY age ASC, patient_id LIMIT 1)
UNION ALL
(SELECT 'Oldest', patient_id, first_name, last_name, age
 FROM v_patients ORDER BY age DESC, patient_id LIMIT 1);

-- Q9: Identify duplicate phone numbers
SELECT phone, count(*) AS patients_sharing_number
FROM patients
GROUP BY phone
HAVING count(*) > 1
ORDER BY patients_sharing_number DESC;

-- Q10: Calculate average patient age
SELECT ROUND(AVG(age), 1) AS average_age
FROM v_patients;
-- Q11: Count appointments by month
SELECT TO_CHAR(appointment_date, 'YYYY-MM') AS month, count(*) AS total_appointments
FROM v_appointments
GROUP BY 1
ORDER BY 1;

-- Q12: Identify busiest hospitals (ranked)
SELECT facility_id, count(*) AS total_appointments,
       RANK() OVER (ORDER BY count(*) DESC) AS busy_rank
FROM v_appointments
GROUP BY facility_id
ORDER BY busy_rank;

-- Q13: Find busiest departments
SELECT d.department_name, count(*) AS total_appointments
FROM v_appointments a
JOIN departments d ON d.department_id = a.department_id
GROUP BY d.department_name
ORDER BY total_appointments DESC;
-- Q14: Find doctors with the highest workload (top 10)
SELECT a.doctor_id, doc.first_name, doc.last_name, doc.specialty,
       count(*) AS total_appointments
FROM v_appointments a
JOIN doctors doc ON doc.staff_id = a.doctor_id
GROUP BY a.doctor_id, doc.first_name, doc.last_name, doc.specialty
ORDER BY total_appointments DESC
LIMIT 10;

-- Q15: Identify referral patterns
-- The data has no referral records, so we look at visit types by hospital instead
SELECT facility_id, visit_type, count(*) AS total_appointments,
       ROUND(100.0 * count(*) / SUM(count(*)) OVER (PARTITION BY facility_id), 1) AS percent_of_hospital
FROM v_appointments
GROUP BY facility_id, visit_type
ORDER BY facility_id, total_appointments DESC;

-- Q16: Count emergency appointments
SELECT count(*) AS emergency_appointments,
       ROUND(100.0 * count(*) / (SELECT count(*) FROM v_appointments), 1) AS percent_of_all
FROM v_appointments
WHERE visit_type = 'Emergency';

-- Q17: Calculate average appointments per doctor
SELECT ROUND(count(*)::numeric / count(DISTINCT doctor_id), 1) AS avg_per_active_doctor,
       ROUND(count(*)::numeric / (SELECT count(*) FROM doctors), 1) AS avg_per_all_doctors
FROM v_appointments;

-- Q18: Retrieve appointments by province
SELECT p.province_name, count(*) AS total_appointments
FROM v_appointments a
JOIN v_patients p ON p.patient_id = a.patient_id
GROUP BY p.province_name
ORDER BY total_appointments DESC;

-- Q19: Identify facilities with the highest patient volume (unique patients)
SELECT facility_id, count(DISTINCT patient_id) AS unique_patients
FROM v_appointments
GROUP BY facility_id
ORDER BY unique_patients DESC;

-- Q20: Find peak consultation periods (by day of the week)
SELECT TRIM(TO_CHAR(appointment_date, 'Day')) AS weekday, count(*) AS consultations
FROM v_appointments
WHERE visit_type = 'Consultation'
GROUP BY 1
ORDER BY consultations DESC;
-- Q21: Top diagnoses (the data contains only 5 different diagnoses)
SELECT diagnosis, count(*) AS total_cases,
       ROUND(100.0 * count(*) / SUM(count(*)) OVER (), 1) AS percent_of_cases
FROM diagnoses
GROUP BY diagnosis
ORDER BY total_cases DESC
LIMIT 20;

-- Q21b (extra): Disease trend by month, to see which diseases are becoming more common
SELECT TO_CHAR(a.appointment_date, 'YYYY-MM') AS month, d.diagnosis, count(*) AS cases
FROM diagnoses d
JOIN v_appointments a ON a.appointment_id = d.appointment_id
GROUP BY 1, 2
ORDER BY 1, cases DESC;

-- Q25: Disease severity distribution
SELECT severity, count(*) AS total_cases,
       ROUND(100.0 * count(*) / SUM(count(*)) OVER (), 1) AS percent_of_cases
FROM diagnoses
GROUP BY severity
ORDER BY total_cases DESC;

-- Q25b (extra): Severity by diagnosis
SELECT diagnosis, severity, count(*) AS total_cases
FROM diagnoses
GROUP BY diagnosis, severity
ORDER BY diagnosis, total_cases DESC;

-- Q29 (proxy): Emergency visit rate by diagnosis
-- The data has no admissions, so the share of emergency visits is used instead
SELECT d.diagnosis, count(*) AS linked_cases,
       SUM(CASE WHEN a.visit_type = 'Emergency' THEN 1 ELSE 0 END) AS emergency_cases,
       ROUND(100.0 * SUM(CASE WHEN a.visit_type = 'Emergency' THEN 1 ELSE 0 END) / count(*), 1) AS emergency_rate_percent
FROM diagnoses d
JOIN v_appointments a ON a.appointment_id = d.appointment_id
GROUP BY d.diagnosis
ORDER BY emergency_rate_percent DESC;

-- Q30: Clinical workload by department
SELECT dep.department_name, count(*) AS diagnosed_cases
FROM diagnoses d
JOIN v_appointments a ON a.appointment_id = d.appointment_id
JOIN departments dep ON dep.department_id = a.department_id
GROUP BY dep.department_name
ORDER BY diagnosed_cases DESC;

-- Q22, Q23, Q24, Q26, Q27, Q28 cannot be answered: the dataset has no laboratory test,
-- prescription, admission or referral records. They are recorded in data_quality_log.
INSERT INTO data_quality_log (table_name, issue, records_affected, action_taken)
VALUES
 ('laboratory tests', 'No laboratory test data provided (Q22, Q26)', 0, 'Not analysed; stated as a limitation'),
 ('prescriptions', 'No prescription data provided (Q23, Q27)', 0, 'Not analysed; stated as a limitation'),
 ('admissions', 'No admission data provided (Q24, Q29)', 0, 'Used emergency visit rate as a proxy for Q29'),
 ('referrals', 'No referral data provided (Q15, Q28)', 0, 'Used visit type distribution as a proxy for Q15');
 -- Revenue here means the billed amount. "Collected" means the payments received.

-- Q31: Revenue by facility (only the 5,000 appointments with facility details)
SELECT a.facility_id, count(*) AS bills, SUM(b.amount) AS revenue
FROM billing b
JOIN v_appointments a ON a.appointment_id = b.appointment_id
GROUP BY a.facility_id
ORDER BY revenue DESC;

-- Q32: Revenue by department
SELECT d.department_name, SUM(b.amount) AS revenue
FROM billing b
JOIN v_appointments a ON a.appointment_id = b.appointment_id
JOIN departments d ON d.department_id = a.department_id
GROUP BY d.department_name
ORDER BY revenue DESC;

-- Q33: Revenue by service type
-- Bills are not linked to individual services, so visit type is used as the service type
SELECT a.visit_type AS service_type, count(*) AS bills, SUM(b.amount) AS revenue
FROM billing b
JOIN v_appointments a ON a.appointment_id = b.appointment_id
GROUP BY a.visit_type
ORDER BY revenue DESC;

-- Q34: Insurance claims by provider
SELECT provider, count(*) AS total_claims, SUM(claim_amount) AS claimed_amount,
       SUM(CASE WHEN status = 'Approved' THEN 1 ELSE 0 END) AS approved_claims,
       ROUND(100.0 * SUM(CASE WHEN status = 'Approved' THEN 1 ELSE 0 END) / count(*), 1) AS approval_rate_percent
FROM insurance_claims
GROUP BY provider
ORDER BY claimed_amount DESC;

-- Q35: Outstanding payments (billed minus paid), by billing status, all 60,000 bills
SELECT b.status, count(*) AS bills, SUM(b.amount) AS billed, SUM(p.amount_paid) AS paid,
       SUM(b.amount) - SUM(p.amount_paid) AS outstanding
FROM billing b
JOIN payments p ON p.billing_id = b.billing_id
GROUP BY b.status
ORDER BY outstanding DESC;

-- Q36: Average billing amount
SELECT ROUND(AVG(amount)) AS average_bill_all_60000,
       (SELECT ROUND(AVG(b.amount))
        FROM billing b JOIN v_appointments a ON a.appointment_id = b.appointment_id) AS average_bill_linked_5000
FROM billing;

-- Q37: Monthly revenue trend (linked appointments only)
SELECT TO_CHAR(a.appointment_date, 'YYYY-MM') AS month, SUM(b.amount) AS revenue
FROM billing b
JOIN v_appointments a ON a.appointment_id = b.appointment_id
GROUP BY 1
ORDER BY 1;

-- Q37b: The official monthly revenue summary table, for comparison
SELECT * FROM revenue_summary;

-- Q38: Payment methods
SELECT method, count(*) AS payments, SUM(amount_paid) AS total_paid,
       ROUND(100.0 * count(*) / SUM(count(*)) OVER (), 1) AS percent_of_payments
FROM payments
GROUP BY method
ORDER BY total_paid DESC;

-- Q39: Top revenue-generating hospitals (top 5)
SELECT a.facility_id, SUM(b.amount) AS revenue,
       RANK() OVER (ORDER BY SUM(b.amount) DESC) AS revenue_rank
FROM billing b
JOIN v_appointments a ON a.appointment_id = b.appointment_id
GROUP BY a.facility_id
ORDER BY revenue_rank
LIMIT 5;

-- Q40: Financial performance ranking of all hospitals
WITH facility_finance AS (
    SELECT a.facility_id,
           SUM(b.amount) AS revenue,
           SUM(p.amount_paid) AS collected,
           ROUND(AVG(b.amount)) AS avg_bill
    FROM billing b
    JOIN v_appointments a ON a.appointment_id = b.appointment_id
    JOIN payments p ON p.billing_id = b.billing_id
    GROUP BY a.facility_id
)
SELECT facility_id, revenue, collected,
       ROUND(100.0 * collected / revenue, 1) AS collection_rate_percent,
       avg_bill,
       RANK() OVER (ORDER BY revenue DESC) AS revenue_rank,
       RANK() OVER (ORDER BY collected / revenue DESC) AS collection_rank
FROM facility_finance
ORDER BY revenue_rank;