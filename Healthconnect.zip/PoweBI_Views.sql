-- All bills with their appointment, department and payment details
CREATE VIEW v_billing_full AS
SELECT b.billing_id, b.appointment_id, b.amount, b.status AS bill_status,
       a.patient_id, a.doctor_id, a.facility_id, a.department_id,
       dep.department_name, a.appointment_date, a.visit_type,
       p.amount_paid, p.method AS payment_method,
       b.amount - p.amount_paid AS outstanding
FROM billing b
LEFT JOIN v_appointments a ON a.appointment_id = b.appointment_id
LEFT JOIN departments dep  ON dep.department_id = a.department_id
LEFT JOIN payments p       ON p.billing_id = b.billing_id;

-- All diagnoses with appointment details
CREATE VIEW v_diagnoses_full AS
SELECT d.diagnosis_id, d.appointment_id, d.diagnosis, d.severity,
       a.patient_id, a.facility_id, a.department_id, dep.department_name,
       a.appointment_date, a.visit_type
FROM diagnoses d
LEFT JOIN v_appointments a ON a.appointment_id = d.appointment_id
LEFT JOIN departments dep  ON dep.department_id = a.department_id;

-- All feedback with appointment details
CREATE VIEW v_feedback_full AS
SELECT f.feedback_id, f.appointment_id, f.rating, f.comment,
       a.facility_id, a.department_id, dep.department_name, a.appointment_date
FROM patient_feedback f
LEFT JOIN v_appointments a ON a.appointment_id = f.appointment_id
LEFT JOIN departments dep  ON dep.department_id = a.department_id;

-- All six staff tables in one list
CREATE VIEW v_staff_all AS
SELECT 'Doctor' AS staff_type, staff_id, facility_id, department_id, years_experience, status FROM doctors
UNION ALL SELECT 'Nurse', staff_id, facility_id, department_id, years_experience, status FROM nurses
UNION ALL SELECT 'Pharmacist', staff_id, facility_id, department_id, years_experience, status FROM pharmacists
UNION ALL SELECT 'Laboratory Scientist', staff_id, facility_id, department_id, years_experience, status FROM laboratory_scientists
UNION ALL SELECT 'Radiographer', staff_id, facility_id, department_id, years_experience, status FROM radiographers
UNION ALL SELECT 'Administrative Staff', staff_id, facility_id, department_id, years_experience, status FROM administrative_staff;

-- Check the row counts
SELECT (SELECT count(*) FROM v_billing_full)   AS billing_rows,
       (SELECT count(*) FROM v_diagnoses_full) AS diagnosis_rows,
       (SELECT count(*) FROM v_feedback_full)  AS feedback_rows,
       (SELECT count(*) FROM v_staff_all)      AS staff_rows;